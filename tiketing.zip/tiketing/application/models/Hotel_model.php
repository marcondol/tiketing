
<?php
class Hotel_model extends CI_Model {

   public $key = 'ejeKgZiJnagE';
   public $url = 'http://apidev.aeroticket.com/service/v2';

   public function post_request($data){
      $ch=curl_init();
      // user credencial
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_URL, $this->url);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $response = curl_exec($ch);      
      return json_decode($response);
   }

   public function get_city_list(){
      $data=array("akses_kode"=>$this->key,
                  "app"  => "hotel_v5",
                  "action"  => "city"
                  );
      return $this->post_request($data);
   }

   public function get_hotel(){
      $data=array("akses_kode"=>$this->key,
                  "app"  => "hotel_v5",
                  "action"  => "hotel_search",
                  "city" => "jakarta",
                  "ci" => "2018-01-05",
                  "co" => "2018-01-07",
                  "room" => "1",
                  "adult" => "1",
                  "child"   => "0",
                  "hotel_name" => "");
      return $this->post_request($data);
   }

}
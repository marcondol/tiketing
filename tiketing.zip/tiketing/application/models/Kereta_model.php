
<?php
class Kereta_model extends CI_Model {

   public $key = 'ejeKgZiJnagE';
   public $url = 'http://apidev.aeroticket.com/service/v2';

   public function post_request($data){
      $ch=curl_init();
      // user credencial
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_URL, $this->url);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $response = curl_exec($ch);      
      return json_decode($response);
   }

   public function get_station(){
      $data=array("akses_kode"=>$this->key ,
                  "app" => "train", 
                  "action"=>"get_station");
      return $this->post_request($data);
   }

   public function get_train($data){    
 
      $data=array("akses_kode"=>$this->key ,
                  "app" => "train", 
                  'action' => "train_search",
                  'roundtrip'  => $data['roundtrip'],
                  'from'    => $data['from'],
                  'to'      => $data['to'],
                  'depart'  => $data['depart'],
                  'adult'=> $data['adult'],
                  'infant'=> $data['child']);
      return $this->post_request($data);
   }
   

}